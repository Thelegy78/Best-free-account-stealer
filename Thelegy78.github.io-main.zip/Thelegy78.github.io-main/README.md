# Thelegy78.github.io
New hacking methods
